#include "fadeColorPicker.h"

fadeColorPicker::fadeColorPicker(double fade)
{
    /* your code here */
}

HSLAPixel fadeColorPicker::operator()(point p)
{
    /* your code here */
}
