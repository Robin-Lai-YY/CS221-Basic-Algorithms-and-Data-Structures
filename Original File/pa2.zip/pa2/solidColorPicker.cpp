#include "solidColorPicker.h"

solidColorPicker::solidColorPicker(HSLAPixel fillColor)
{
    /* your code here */
}

HSLAPixel solidColorPicker::operator()(point p)
{
    /* your code here */
}
