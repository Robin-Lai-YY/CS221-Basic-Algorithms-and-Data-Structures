#include "borderColorPicker.h"

borderColorPicker::borderColorPicker(unsigned int borderSize, HSLAPixel fillColor, PNG &img, double tolerance)
{
    /* your code here */
}

HSLAPixel borderColorPicker::operator()(point p)
{
    /* your code here */
}
